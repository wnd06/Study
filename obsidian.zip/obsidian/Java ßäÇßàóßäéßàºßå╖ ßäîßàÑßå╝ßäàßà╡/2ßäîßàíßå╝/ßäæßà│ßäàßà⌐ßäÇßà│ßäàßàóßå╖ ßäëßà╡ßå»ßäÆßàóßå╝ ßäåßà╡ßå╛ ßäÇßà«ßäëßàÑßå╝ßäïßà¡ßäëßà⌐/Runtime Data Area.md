![](https://blog.kakaocdn.net/dn/cEjHLD/btq4YtqCAGY/rrVrI45UWSH2LqslkP8Wg0/img.png)

프로그램을 수행하기 위해 OS에서 할당받은 메모리 공간.

##### PC Register
- [[Thread]]가 시작될 때 생성되며 생성될 떄마다 생성되는 공간으로, [[Thread]]마다 하나씩 존재한다.
- [[Thread]]가 어떤 부분을 어떤 명령으로 실행해야 할 지에 대한 기록을 하는 부분으로 현재 수행 중인 JVM 명령의 주소를 갖는다.

##### [[JVM Stack 영역]]

##### [[Native method stack]]

##### [[Method Area]](= Class Area = Static area)

##### [[Runtime constant Pool]]

##### [[Heap 영역]]