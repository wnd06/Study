![](https://blog.kakaocdn.net/dn/mxiE4/btq4Y5pwyCR/3nO3XIf20wUUTrzMKvn5yk/img.png)

- 객체를 저장하는 가상메모리 공간. new 연산자로 생성되는 객체(instance)와 배열을 저장한다.

- Class Area(Static Area)에 올라온 클래스들만 객체로 생성할 수 있다.

- heap은 세 부분으로 나누어진다.
	- [[Permanent Generation]]
	- [[New, Young 영역]]
	- [[Old 영역]]
