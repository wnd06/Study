[[process]] 내에서 실제로 작업을 수행하는 주체를 의미한다.
모든 process에는 한 개 이상의 스레드가 존재하여 작업을 수행한다.
또한, 두 개 이상의 스레드를 가지는 process를 multi-threaded-process라고 한다.l