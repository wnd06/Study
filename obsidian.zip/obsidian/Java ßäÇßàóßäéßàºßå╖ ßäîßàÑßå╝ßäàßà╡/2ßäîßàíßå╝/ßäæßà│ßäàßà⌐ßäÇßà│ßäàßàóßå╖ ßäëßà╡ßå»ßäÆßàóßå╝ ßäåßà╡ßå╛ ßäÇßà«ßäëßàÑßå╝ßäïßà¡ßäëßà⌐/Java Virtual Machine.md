#### JVM 개념
- OS에 종속 받지 않고 CPU가 Java를 인식, 실행할 수 있게 하는 가상 컴퓨터이다.

- Java 소스 코드는 CPU가 인식을 하지 못하므로 기계어로 컴파일을 해줘야 한다. 하지만 Java는 이 JVM이라는 가상머신을 거쳐서 OS에 도달하기 때문에 OS가 인식할 수 있는 기계어로 바로 컴파일 되는 것이 아니라 JVM이 인식할 수 있는 Java bytecode(.class -> [[javac]]가 만들어냄.)를 읽고 실행하는 것이다.

- 여기서 byte code는 기계어가 아니기 때문에 OS에서 바로 실행되지 않는다.

- 그래서, JVM이 OS가 byte code를 이해 할 수 있도록 해석해주는 것이다.

#### JVM 구성요소

![](https://blog.kakaocdn.net/dn/tclVx/btq4Xfml6Dy/nzb5xxlGG1fr5iBGUMv77K/img.png)

- 클래스 로더([[Class Loader]])
- 실행 엔진([[Execution Engine]])
	- 인터프리터(Interpreter)
	- JIT 컴파일러(JIT Compiler)
	- 가비지 콜렉터(Garbage Collector)
- 런타임 데이터 영역 ([[Runtime Data Area]])