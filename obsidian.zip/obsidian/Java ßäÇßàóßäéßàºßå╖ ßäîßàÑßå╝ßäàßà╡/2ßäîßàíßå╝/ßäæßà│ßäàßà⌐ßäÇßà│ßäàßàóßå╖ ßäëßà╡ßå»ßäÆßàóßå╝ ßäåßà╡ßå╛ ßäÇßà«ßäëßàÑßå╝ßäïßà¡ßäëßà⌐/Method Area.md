
Method Area = Class Area = Static Area
클래스의 정보를 처음 메모리 공간에 올릴 때 초기화 되는 대상을 저장하기 위한 메모리 공간.

##### static Area에 저장되는 데이터
- Field information(멤버 변수)
	- 멤버변수의 이름, 데이터 타입, 접근 제어자에 대한 정보
- Method Information
	- 메소드의 이름, 리턴 타입, 매개변수, 접근 제어자에 대한 정보
- Type Information(타입)
	- class 인지 interface인지의 여부 저장. Type의 속성, 전체 이름, super클랫의 전체 이름.
	- (interface이거나 object인 경우 제외된다. 이것들은 Heap 영역에서 관리한다.)