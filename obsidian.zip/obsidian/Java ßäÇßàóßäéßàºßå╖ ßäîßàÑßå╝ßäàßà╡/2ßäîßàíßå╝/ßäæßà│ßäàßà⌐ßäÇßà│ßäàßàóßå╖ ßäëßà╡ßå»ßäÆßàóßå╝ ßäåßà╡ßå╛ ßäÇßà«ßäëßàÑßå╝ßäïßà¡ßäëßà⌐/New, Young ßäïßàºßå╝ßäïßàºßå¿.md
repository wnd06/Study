
- 이곳의 인스턴스들은 추후 Garbage Collector에 의해 사라진다. 

- 생명 주기가 짧은 Young객체를 GC대상으로 하는 영역이다. 

- 여기서 일어나는 Garbage Collector를 Minor GC라고 한다.
	Eden : 객체들이 최초로 생성되는 공간
	Survivor 0, 1 : Eden에서 참조되는 객체들이 저장되는 공간.
	Eden 영역에 객체가 가득차게 되면 첫번째 가비지 콜렉트가 발생한다.
	Eden 영역에 있는 값들은 Survivor 1 영역에 복사하고 이 영역을 제외한 나머지 객체를 삭제한다.
