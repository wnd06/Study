
- java compiler의 줄임말이기도 하다. 
 
- .java 파일을 .class파일로 컴파일 해주는 compiler이다. 이 때 컴파일이 된 class 파일 안의 코드는 byte code로 생성되어 있다.