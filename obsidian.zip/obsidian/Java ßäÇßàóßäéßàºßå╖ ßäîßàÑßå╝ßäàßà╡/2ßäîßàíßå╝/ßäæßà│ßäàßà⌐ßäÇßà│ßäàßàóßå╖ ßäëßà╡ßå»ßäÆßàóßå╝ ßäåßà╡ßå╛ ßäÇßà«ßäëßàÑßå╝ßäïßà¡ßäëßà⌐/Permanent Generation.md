
생성된 객체들의 정보의 주소값이 저장된 공간이다. [[Class Loader]]에 의해 load되는 class, Method 등에 대한 Meta 정보가 저장되는 영역이고 JVM에 의해 사용된다.
[[Reflection]]을 사용하여 동적으로 클래스가 로딩되는 경우에 사용된다.