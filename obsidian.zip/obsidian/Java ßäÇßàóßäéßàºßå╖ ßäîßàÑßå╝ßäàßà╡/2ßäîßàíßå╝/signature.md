
- 메소드의 위에 어떤 메소드인지 알려주는 기본 적인 것들을 signature라 한다.
	- 예시 : public static void name(type parameter){} -> signature

- 예를 들어 public static String MethodName(parameter); -> public, return type, MethodName, parameter를 시그니처라 한다.

여기 4개중 하나라도 없으면 시그니처가 없다가 말 할 수 있으며 오버로딩은 두개의 메서드 시그니처가 다르면 사용할 수 있다.
