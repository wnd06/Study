
### notify()

- notify() - waiting pool에서 대기중인 스레드 하나(아무거나)를 깨운다. 
	- ex) 귓속말
- notifyAll() - waiting pool에서 대기중인 모든 스레드를 깨운다.
	- ex) 방송