
### Thread의 실행제어

#### 1. [[Sleep()]]

#### 2. [[Interrupt()]]