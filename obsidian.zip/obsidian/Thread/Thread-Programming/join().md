
### join()

- 지정된 시간동안 특정 스레드가 작업하는 것을 기다린다.
```java
void join() // 작업이 모두 끝날 때까지 기다린다.
void join(long millis) // 천분의 1초 동안
```