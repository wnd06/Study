## 캡슐화

- 코드 은닉화를 위한 도구이다. 데이터를 외부로 숨기거나, 접근을 막고, 또는 접근에 처리를 강제화 한다.
> Encapsulation
>  1. 유사한 기능이나 변수를 한 집합으로 하여 더 관리하기 쉽게하고 코드를 명확히 함.(객체의 속성이나 행위를 집합화)
>  2. 외부에서 멤버를 액세스하는 방법을 지정할 수 잇도록, 직접 접근을 막거나 접근 전 부가적인 처리를 요구한다.(Setter)
>  3. 정보를 외부에 은닉하여 외부에서는 해당 집합의 세부 내용에 집중하지 않도록 한다.(Getter)

## Setter

- 만약 사람이라는 객체에서의 변수가 age일 때 age는 음수가 될 수 없다. 
- 음수가 입력되면 0을 대입하도록 하여 나이에 음수가 대입되는 상황을 처리할 수 있다.
```java
class Person{ 
	private int age; 
	public void setAge(int age) {
		 if(age >=0){ 
			 this.age = age; 
		 } else this.age = 0; 
		} 
	void howOld(){ System.out.println(age); } }
```

## Getter

- 매우 긴 코드를 다룬다고 생각해보자. 이제 객체의 코드 속에 있는 모든 변수 값을 가져올 필요도 없으며, 가져 올 수 있는 것이 마냥 편한 일은 아닐 것이다.
- 객체에서 내가 원하는 정보만 필요하지 불필요한 정보에 신경이 가는 것은 좋지 않다.
- 그래서 객체 변수들을 모두 private로 선언해준다. 사용하는 객체에서 꼭 필요한 변수들은 getter를 이용해 드러낸다.
- 이렇게 변수들의 외부 노출을 제한하고, 노출 범위를 정해주는 것이 Getter이고, 이런 속성이 은닉성이다.
```java
class Person{
    private int age;
    private int name;
    
    private String hobby;
    private int hobby_id;
    private String school;
    private int school_id;
    private String phoneNumber;
    private int gender;
    private int pw;

    public int getAge() {
        return age;
    }

    public int getName() {
        return name;
    }

    public void setAge(int age) {
        if(age >=0){
            this.age = age;
        }
        else
            this.age = 0;
    }
}
```