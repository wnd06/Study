#### Computer

![[Pasted image 20231012134416.png]]
- [[CPU]](Central Processing Unit)
- [[Program]]
- [[Main memory]]