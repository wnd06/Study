
### JOIN 종류

1. INNER JOIN : 내부 조인 -> 교집합
2. LEFT/RIGHT JOIN -> 부분 집합
3. OUTER JOIN : 외부 조인 / 합집합
 4. MySQL 은 없어서 LEFT 조인 + RIGHT 조인 