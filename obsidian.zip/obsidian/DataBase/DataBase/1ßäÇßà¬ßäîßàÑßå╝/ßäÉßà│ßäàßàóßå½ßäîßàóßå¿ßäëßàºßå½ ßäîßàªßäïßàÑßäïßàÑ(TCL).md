
### TCL
- 논리적인 작업의 단위를 묶어서 DML에 의해 조작된 결과를 트랜잭션 별로 제어하는 질의어
- 트랜잭션의 시작과 끝을 명시하는 명렁어를 포함한다.

#### TCL 구성

- COMMIT
- ROLLBACK
- SAVEPOINT