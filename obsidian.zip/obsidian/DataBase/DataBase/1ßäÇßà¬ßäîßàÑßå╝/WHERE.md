
### WHERE 절
- FROM절에 나타나는 릴레이션 속성들의 조건으로 구성
	- 식 op 식 형태의 조건들을 조합한 boolean 식
	- op = 비교연산자
	- 범위 연산을 위해 BETWEEN 비교 연산을 제공